Important link:

* [Running MongoDB locally for development](https://www.mongodb.com/docs/manual/tutorial/install-mongodb-on-os-x/)
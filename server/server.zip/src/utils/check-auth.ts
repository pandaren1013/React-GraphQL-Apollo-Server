// const { AuthenticationError } = require('apollo-server');

// const jwt = require('jsonwebtoken');
// const secretKey = require('../../config/key.config').SECRET_KEY;

// module.exports = (context) => {
//   // context = { ... headers }
//   const authHeader = context.req.headers.authorization;
//   if (authHeader) {
//     // Bearer ....
//     const token = authHeader.split('Bearer ')[1];
//     if (token) {
//       try {
//         const user = jwt.verify(token, secretKey);
//         return user;
//       } catch (err) {
//         throw new AuthenticationError('Invalid/Expired token');
//       }
//     }
//     throw new Error("Authentication token must be 'Bearer [token]");
//   }
//   throw new Error('Authorization header must be provided');
// };
// import { AuthenticationError } from 'apollo-server';
import  {AuthenticationError}  from "@apollo/server";

import jwt from 'jsonwebtoken';
import { SECRET_KEY } from '../../config/key.config';

// Add type definitions for the context object and the user object if necessary
// For example:
// interface Context {
//   req: {
//     headers: {
//       authorization: string;
//     };
//   };
// }

export default (context: any) => {
  // context = { ... headers }
  const authHeader: string = context.req.headers.authorization;
  if (authHeader) {
    // Bearer ....
    const token: string = authHeader.split('Bearer ')[1];
    if (token) {
      try {
        const user: any = jwt.verify(token, SECRET_KEY);
        return user;
      } catch (err) {
        throw new AuthenticationError('Invalid/Expired token');
      }
    }
    throw new Error("Authentication token must be 'Bearer [token]");
  }
  throw new Error('Authorization header must be provided');
};
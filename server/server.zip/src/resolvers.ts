import db from "./db/conn.js";
import { ObjectId } from "mongodb";
import User from './models/User';
import  UserInputError  from "@apollo/server";

import {validateRegisterInput, validateLoginInput} from './utils/validator';


const resolvers = {
  Record: {
    id: (parent) => parent.id ?? parent._id,
  },
  Query: {
    async record(_, { id }, context) {
      let collection = await db.collection("records");
      let query = { _id: new ObjectId(id) };

      return await collection.findOne(query);
    },
    async records(_, __, context) {
      let collection = await db.collection("records");
      const records = await collection.find({}).toArray();
      return records;
    },

    async sort_users(_, { page = 1, limit = 5, sortBy = "name" }, context) {
      try {
        const collection = await db.collection("records");
        const startIndex = (page - 1) * limit;
        const endIndex = page * limit;
        
        const sortField = sortBy === "name" ? "name" : sortBy === "age" ? "age" : "createdAt"; // Assuming "createdAt" field exists
    
        const sortedUsers = await collection.find({})
          .sort({ [sortField]: 1 })
          .skip(startIndex)
          .limit(limit)
          .toArray();
          
        return sortedUsers;
      } catch (error) {
        console.error("Error sorting users:", error);
        throw new Error("Failed to sort users.");
      }
    }
    // async sort_users(_,  { page = 1, limit = 3, sortBy = "name" },context) {
    //   let collection = await db.collection("records");
    //   // const sort_users = await collection.find({}).toArray();
    //   const startIndex = (page - 1) * limit;
    //   const endIndex = page * limit;
    //   const sortedUsers = collection.sort((a, b) =>
    //     a[sortBy] > b[sortBy] ? 1 : -1
    //   );
    //   return sortedUsers.slice(startIndex, endIndex);
    //   // return sort_users;
    // },
    // users: (parent, { page = 1, limit = 3, sortBy = "name" }) => {
    //   // Apply pagination and sorting
    //   const startIndex = (page - 1) * limit;
    //   const endIndex = page * limit;
    //   const sortedUsers = users.sort((a, b) =>
    //     a[sortBy] > b[sortBy] ? 1 : -1
    //   );
    //   return sortedUsers.slice(startIndex, endIndex);
    // },
  },
  Mutation: {
    async register(_,
      {
          signup: { userName, email, password, confirmPassword} //args
          
      }/*, context, info*/) {
          const {valid, errors} = validateRegisterInput(
              userName,
              email,
              password,
              confirmPassword
          );

           if(!valid) {
               throw new UserInputError('Errors', {errors});
           }   

          const user = await User.findOne({userName});

          if(user) {
              throw new UserInputError('Username is taken', {
                  errors:{
                      username: 'This username is taken'
                  }
              });
          }

          password = await bycrypt.hash(password, 12);
          const newUser = new User({
              email,
              userName,
              password,
          });
          const result = await newUser.save();

          const token = userToken.defaultToken(result)

          // Return data in localhost:5000 saved in mongodb
          return {
              ...result._doc,
              id: result._id,
              token
          }
  },
    async createRecord(_, { name, position,score, level }, context) {
      let collection = await db.collection("records");
      const insert = await collection.insertOne({ name, position,score, level });
      if (insert.acknowledged)
        return { name, position,score, level, id: insert.insertedId };
      return null;
    },
    async sortRecord(_, { page , limit = 5 }, context) {
      try {
        const collection = await db.collection("records");
        const startIndex = (page - 1) * limit;
        const endIndex = page * limit;
        
        // const sortField = sortBy === "name" ? "name" : sortBy === "age" ? "age" : "createdAt"; // Assuming "createdAt" field exists
    
        const sortedUsers = await collection.find({})
          .skip(startIndex)
          .limit(limit)
          .toArray();
          
        return sortedUsers;
      } catch (error) {
        console.error("Error sorting users:", error);
        throw new Error("Failed to sort users.");
      }
    },
    // async sortRecord(_, { page = 1, limit = 3, sortBy = "name" },context ) {
    //   let collection = await db.collection("records");
    //   // const sort_users = await collection.find({}).toArray();
    //   const startIndex = (page - 1) * limit;
    //   const endIndex = page * limit;
    //   const sortedUsers = collection.sort((a, b) =>
    //     a[sortBy] > b[sortBy] ? 1 : -1
    //   );
    //   return sortedUsers.slice(startIndex, endIndex);
    //   // return sort_users;
    // },
    async updateRecord(_, args, context) {
      const id = new ObjectId(args.id);
      let query = { _id: new ObjectId(id) };
      let collection = await db.collection("records");
      const update = await collection.updateOne(
        query,
        { $set: { ...args } }
      );
      
      if (update.acknowledged) 
        return await collection.findOne(query);
      
      return null;
    },
    async deleteRecord(_, { id }, context) {
      let collection = await db.collection("records");
      const dbDelete = await collection.deleteOne({ _id: new ObjectId(id) });
      return dbDelete.acknowledged && dbDelete.deletedCount == 1 ? true : false;
    },
  },
};

export default resolvers;

// import { model, Schema }  from 'mongoose';
import * as mongoose from 'mongoose';
const User=new mongoose.Schema(
{
// const userSchema = new Schema({
  userName: String,
  password: String,
  email: String,
  createdAt: {
    type: Date,
    default: Date.now
},

});

// module.exports = model('User', userSchema);
export default User;
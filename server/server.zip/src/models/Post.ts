// import { model, Schema } from 'mongoose';
import * as mongoose from 'mongoose';
import { Schema } from 'mongoose';
const Post=new mongoose.Schema(
{
// const postSchema = new Schema({
  body: String,
  userName: String,
  createdAt: {
    type: Date,
    default: Date.now
},
  comments: [
    {
      body: String,
      username: String,
      createdAt: String
    }
  ],
  likes: [
    {
      username: String,
      createdAt: {
        type: Date,
        default: Date.now
    }
    }
  ],
  user: {
    type: Schema.Types.ObjectId,
    ref: 'user'
  }
});

// module.exports = model('Post', postSchema);
export default Post;
